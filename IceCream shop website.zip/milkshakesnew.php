<?php
session_start();
?>
<!DOCTYPE html>
<html>

	<head>
		<title> Milkshake Order </title>
		<link rel="stylesheet" type="text/css" href="milkshakescss.css">
		
		<script type="text/javascript">
		
		function validateform(){
		var val=true;
		var valc=false;
		var v1=false;
		var v2=false;
		var v3=false;
		
		 
		
		//validation to select a number
		if(val){
		var e;
		var d;
		e= document.getElementById("type");
		
		d = e.options[e.selectedIndex].value;
		
		if(d==0){
			alert("Please Select number of scoops!!!")
		}
		else v1=true;
		
		
		//validation to select milk type
		var r = document.getElementsByName("served")
		var c = -1

		for(var i=0; i < r.length; i++){
		if(r[i].checked) {
		c = i; 
		}
		}
		if (c == -1) alert("Please select a milk type !!!");
		else v2=true;
		
		
		//validation to select atleast one flavours
		var checkboxs=document.getElementsByName("flavour[]");
		var okay=false;
		var count=0;
		for(var j=0,l=checkboxs.length;j<l ;j++)
		{
			if(checkboxs[j].checked)
			{
            count++;
            }
			}
		if(count<1)alert("Please select atleast one flavour!!!");
		else v3=true;
		
		}
		
		if(v1 && v2 && v3)calprice();
				
		}
						
		function calprice(){
		
		var type1;
		var newline="";
		
		var sum=0;
		var flavours="";
		var e= document.getElementById("type");
		
		if(e!==null){
		type1=e.options[e.selectedIndex].text;
		//sum= parseInt(e.options[e.selectedIndex].value);
		sum= parseInt(e.options[e.selectedIndex].id);
		//sum=parseInt(type1);
		}
				
	 if( document.getElementById("Strawberry").checked==true) sum+=1.50;
     
	 if( document.getElementById("French Vanilla").checked==true)sum+=1.75;
     
	 if( document.getElementById("Banana").checked==true) sum+=1.50;
     
	 if( document.getElementById("Coffee").checked==true)sum+=1.75;
	 if( document.getElementById("Chocolate").checked==true) sum+=2.50;
	 if( document.getElementById("Salty Caramal").checked==true) sum+=1.70;
	 if( document.getElementById("White Chocolate Ginger").checked==true) sum+=2.50;
	 if( document.getElementById("1").checked==true)sum+=0.50;
	 if( document.getElementById("2").checked==true) sum+=1.00;
	 if( document.getElementById("3").checked==true) sum+=1.50;
	 if( document.getElementById("4").checked==true) sum+=2.00;
	 
     var length = flavours.length;
     flavours = flavours.slice(0,length-2);

     document.getElementById("opta").innerHTML = "$"+sum;
	 discount=sum*0.05;
    }
	
	function showDiv() {
	document.getElementById('welcomeDiv').style.display = "block";
	}
    
	 function validateEmail()
      {
         var emailID = document.paymentform.EMail.value;
         atpos = emailID.indexOf("@");
         dotpos = emailID.lastIndexOf(".");
         
         if (atpos < 1 || ( dotpos - atpos < 2 )) 
         {
            alert("Please enter correct email ID")
            document.paymentform.EMail.focus() ;
            return false;
         }
         return( true );
      }
   </script>
		
	</head>

	<body class="b">
	<center>
		
		<div>
		<h4>Choose number of scoops</h4>
		
		
		<form action="datatodb.php" method="post"  name="paymentform"   onsubmit="return validateEmail()">
		
		<table style="background:pink">
		<select name="number" id="type">
			<option value="0">--select a Number--</option>
			<option value="One Scoop" id=1  >One Scoop</option>
			<option value="Two Scoop" id=2 >Two Scoops</option>
			<option value="Three Scoop" id=3 >Three Scoops</option>
			<option value="Four Scoop" id=4>Four Scoops</option>
		</select></table>
		
		<h4>Choose combination of milk to be mixed with: </h4>
		
		<table style="background:pink">
		<tr><td><input type="radio" name="served" value="Waffle Cone" id="1">Skimmed milk</td></tr>
		<tr><td><input type="radio" name="served" value="Waffle Cup" id="2">Whole milk</td></tr>
		<tr><td><input type="radio" name="served" value="Sundae Cup" id="3">2% milk</td></tr>
		</table>
				
		<h4>Choose your  favourite flavour</h4>
		<table style="background:pink">
		<tr><td><INPUT TYPE=CHECKBOX NAME="flavour[]" id="Strawberry" value="Strawberry">Strawberry</td><td><INPUT TYPE=CHECKBOX NAME="flavour[]" id="Coffee" value="Coffee">Coffee</td></tr>
		<tr><td><INPUT TYPE=CHECKBOX NAME="flavour[]" id="Banana" value="Banana">Banana</td><td><INPUT TYPE=CHECKBOX NAME="flavour[]" id="Salty Caramal" value="Salty Caramal">Salty Caramel</td></tr>
		<tr><td><INPUT TYPE=CHECKBOX NAME="flavour[]" id="Chocolate" value="Chocolate">Chocolate</td><td><INPUT TYPE=CHECKBOX NAME="flavour[]" id="White Chocolate Ginger" value="White Chocolate Ginger">White Chocolate Ginger</td></tr>
		<tr><td><INPUT TYPE=CHECKBOX NAME="flavour[]" id="French Vanilla" value="French Vanilla">French Vanilla</td></tr>
		</table><br/>
		
		<input type="button" align = "center" onclick="validateform();" value="Price"/>
		<button type="reset" value="Reset">Clear</button>	   
		 <p id="op" class="outp">
		<h4>Click Price to get the price of Milkshake</h4>
		<textarea id="opta" name="total" style="border-color:white;" rows="1" cols="5" readonly></textarea>
		</p>
		
		<div id="welcomeDiv"  style="display:none;" class="answer_list" >
		<h4>Payment</h4>
		
		<table>
		<tr><td>First Name : </td><td><input type="text" name="fname" id="fname" required="required"></td></tr>
		<tr><td>Last Name : </td><td><input type="text" name="lname" id="lname" required></td></tr>
		<tr><td>Email : </td><td><input type="text" name="EMail"  /></td></tr>
		<tr><td>Card number : </td><td><input type="number" name="card" id="card" maxlength="16" required></td></tr>
		<tr><td>CVV : </td><td><input type="number" name="pswd" id="pswd" minlength="10" maxlength="3" required></td></tr>
		<tr><td>Card Expiry : </td><td><input type="date" name="date" id="date" required></td></tr>
		<tr><td><input type="submit" name="payment" value="Payment" </td></tr>
		</table>
		</form>
		
		</div>
		<input type="button" name="answer" value="Make Payment" onclick="showDiv()" />
		</div>
	</center>
	</body>
</html>