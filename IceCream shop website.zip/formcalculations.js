 //Set up an associative array
 //The keys represent the size of the cake
 //The values represent the cost of the cake i.e A 10" cake cost's $35
 var Cone_prices = new Array();
 Cone_prices["one1"]=2;
 Cone_prices["two2"]=2.5;
 Cone_prices["three3"]=3;
 Cone_prices["four4"]=3.5;
 
var Flavour_prices=new Array();
Flavour_prices["Banana"]=1;
Flavour_prices["Strawberry"]=2;
Flavour_prices["Chocolate"]=2;
Flavour_prices["French vanilla"]=2;
Flavour_prices["Coffee"]=2;
Flavour_prices["Salty Caramel"]=2;
Flavour_prices["White Chocolate Ginger"]=2;
 
var Servingbowl_prices=new array();
Servingbowl_prices["Waffle Cone"]=1;
Servingbowl_prices["Waffle Cup"]=1;
Servingbowl_prices["Sundae Cone"]=1;
	 
	 
// getCakeSizePrice() finds the price based on the size of the cake.
// Here, we need to take user's the selection from radio button selection
function getConePrice()
{  
    var ConePrice=0;
    //Get a reference to the form id="icecreamconeform"
    var theForm = document.forms["icecreamconeform"];
    //Get a reference to the cake the user Chooses name=selectedCake":
    var selectedScoops = theForm.elements["selectedscoops"];
    //Here since there are 4 radio buttons selectedCake.length = 4
    //We loop through each radio buttons
    for(var i = 0; i < selectedScoops.length; i++)
    {
        //if the radio button is checked
        if(selectedScoops[i].checked)
        {
            //we set cakeSizePrice to the value of the selected radio button
            //i.e. if the user choose the 8" cake we set it to 25
            //by using the cake_prices array
            //We get the selected Items value
            //For example cake_prices["Round8".value]"
            ConePrice = Cone_prices[selectedscoops[i].value];
            //If we get a match then we break out of this loop
            //No reason to continue if we get a match
            break;
        }
    }
    //We return the cakeSizePrice
    return ConePrice;
}

<!--//This function finds the filling price based on the 
//drop down selection
function getFillingPrice()
{
    var cakeFillingPrice=0;
    //Get a reference to the form id="cakeform"
    var theForm = document.forms["cakeform"];
    //Get a reference to the select id="filling"
     var selectedFilling = theForm.elements["filling"];
     
    //set cakeFilling Price equal to value user chose
    //For example filling_prices["Lemon".value] would be equal to 5
    cakeFillingPrice = filling_prices[selectedFilling.value];

    //finally we return cakeFillingPrice
    return cakeFillingPrice;
}-->

//candlesPrice() finds the candles price based on a check box selection
function getFlavourPrice()
{
    var flavourPrice=0;
    //Get a reference to the form id="icecreamconeform"
    var theForm = document.forms["icecreamconeform"];
    //Get a reference to the checkbox id="includecandles"
    var flavourPrice = theForm.elements["Banana"];

    //If they checked the box set candlePrice to 5
    if(Banana.checked==true)
    {
        flavourPrice=1;
    }
if(Strawberry.checked==true)
    {
        flavourPrice=1;
    }
if(Chocolate.checked==true)
    {
        flavourPrice=1;
    }
if(French vanilla.checked==true)
    {
        flavourPrice=1;
    }
if(Coffee.checked==true)
    {
        flavourPrice=1;
    }
if(Salty Caramel.checked==true)
    {
        flavourPrice=1;
    }
if(White Chocolate Ginger.checked==true)
    {
        flavourPrice=1;
    }



    //finally we return the candlePrice
    return flavourPrice;
}
function getServingbowlPrice()
{  
    var ServingbowlPrice=0;
    //Get a reference to the form id="icecreamconeform"
    var theForm = document.forms["icecreamconeform"];
    //Get a reference to the cake the user Chooses name=selectedCake":
    var selectedserved = theForm.elements["selectedserved"];
    //Here since there are 4 radio buttons selectedCake.length = 4
    //We loop through each radio buttons
    for(var i = 0; i < selectedserved.length; i++)
    {
        //if the radio button is checked
        if(selectedserved[i].checked)
        {
            //we set cakeSizePrice to the value of the selected radio button
            //i.e. if the user choose the 8" cake we set it to 25
            //by using the cake_prices array
            //We get the selected Items value
            //For example cake_prices["Round8".value]"
            ServingbowlPrice = Servingbowl_prices[selectedserved[i].value];
            //If we get a match then we break out of this loop
            //No reason to continue if we get a match
            break;
        }
    }
    //We return the cakeSizePrice
    return ServingbowlPrice;
}



<!--function insciptionPrice()
{
    //This local variable will be used to decide whether or not to charge for the inscription
    //If the user checked the box this value will be 20
    //otherwise it will remain at 0
    var inscriptionPrice=0;
    //Get a refernce to the form id="cakeform"
    var theForm = document.forms["cakeform"];
    //Get a reference to the checkbox id="includeinscription"
    var includeInscription = theForm.elements["includeinscription"];
    //If they checked the box set inscriptionPrice to 20
    if(includeInscription.checked==true){
        inscriptionPrice=20;
    }
    //finally we return the inscriptionPrice
    return inscriptionPrice;
}-->
        
function calculateTotal()
{
    //Here we get the total price by calling our function
    //Each function returns a number so by calling them we add the values they return together
    var TotalPrice = getConePrice() + getFlavourPrice() + getServingbowlPrice() ;
    
    //display the result
    var divobj = document.getElementById('totalPrice');
    divobj.style.display='block';
    divobj.innerHTML = "Total Price For the Cone is $"+TotalPrice;

}

function hideTotal()
{
    var divobj = document.getElementById('totalPrice');
    divobj.style.display='none';
}