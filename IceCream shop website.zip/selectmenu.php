<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head><style>
body{
background-color:linen;
	}
	img {
   border-radius:50%;
 opacity: 0.8;
    filter: alpha(opacity=80); /* For IE8 and earlier */
}

img:hover {
    opacity:1.0;    
filter: alpha(opacity=100); /* For IE8 and earlier */
}
a {
    display: inline-block;
    border: 1px solid #ddd;
    border-radius: 2px;
    padding: 5px;
    transition: 0.3s;
}

a:hover {
    box-shadow: 0 0 2px 1px rgba(0, 140, 186, 0.5);
}
div.container {
  text-align: center;
  padding: 10px 20px;
}

</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("button").click(function(){
        $("#div1").fadeIn();
        $("#div2").fadeIn("slow");
        $("#div3").fadeIn(3000);
		$("#p1").css("color","blue")
		.slideUp(2000)
		.slideDown(2000);
    });
});
function check(checkbox) {  
 document.getElementById(checkbox).checked = "checked";  
 } 
 
 
</script>
</head>
<body>
  
<center><p id="p1">Please click on the below button to select your order and ice cream type</p>

<button>Select</button><br><br>

<div id="div1" name="Icecream" style="display:none;"><a target="_blank" href="icecreamcones.php"><img src="icecreamcone.jpg" alt="FinalLogo.jpg" width=200 height=200 onclick="javascript:check('checkbox');"><input type="checkbox" name="checkbox" id="checkbox" />  <div class="container">
    <p>Ice Cream Cones</p>
  </div></a></div><br>
<div id="div2" name="Milkshake" style="display:none;"><a target="_blank" href="milkshakesnew.php"><img src="Santa and Snowman Milkshakes.jpg" alt="FinalLogo.jpg" width=200 height=200 onclick="javascript:check('checkbox');"><input type="checkbox" name="checkbox" id="checkbox" />  <div class="container">
    <p>Milkshakes</p>
  </div></a></div><br>
<div id="div3" name="Float" style="display:none;"><a target="_blank" href="floatnew.php"><img src="Vanilla-Cherry-Ice-Cream-Floats.jpg" alt="FinalLogo.jpg" width=200 height=200 onclick="javascript:check('checkbox');"><input type="checkbox" name="checkbox" id="checkbox" />  <div class="container">
    <p>Floats</p>
  </div></a></div><br/>
<button type="submit"> Submit </button>

</body>
</html>
