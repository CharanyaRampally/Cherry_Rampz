var Button=React.createClass({
  render:function(){
    return(
      <button>Go</button>
      )
  }
});

React.render(<Button />, document.getElementById("root"));